namespace TestApi1.Areas.HelpPage.ModelDescriptions
{
    public class SimpleTypeModelDescription : ModelDescription
    {
    }
}